import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class HotelReservation extends JFrame{
    Scanner input = new Scanner(System.in);

    private JButton reservationsButton;
    private JButton  servicesButton;
    private JButton  cityButton;
    private JMenuBar menuBar;
    private JTextArea textArea;

    LinkedList<Calculable> calculableList = new LinkedList<Calculable>();

    public HotelReservation() {


        JMenu fileMenu = new JMenu ("File");

        JMenuItem exitItem = new JMenuItem ("Exit");
        fileMenu.add (exitItem);

        JMenu newMenu = new JMenu ("New");
        JMenuItem createReservation = new JMenuItem ("Reservation");
        newMenu.add (createReservation);
        JMenuItem createService = new JMenuItem ("Service");
        newMenu.add (createService);

        JMenu helpMenu = new JMenu ("Help");
        JMenuItem contentsItem = new JMenuItem ("Contents");
        helpMenu.add (contentsItem);
        JMenuItem aboutItem = new JMenuItem ("About");
        helpMenu.add (aboutItem);


        reservationsButton = new JButton ("Display Reservations");
        servicesButton = new JButton ("Display Extra Services");
        cityButton = new JButton ("Disp. Res. For City");

        menuBar = new JMenuBar();
        menuBar.add (fileMenu);
        menuBar.add (newMenu);
        menuBar.add (helpMenu);
        textArea = new JTextArea (5, 5);


        setPreferredSize (new Dimension (535, 396));
        setLayout (null);


        add (reservationsButton);
        add (servicesButton);
        add (cityButton);
        add (menuBar);
        add (textArea);



        reservationsButton.setBounds (75, 35, 185, 20);
        servicesButton.setBounds (275, 35, 185, 20);
        cityButton.setBounds(180, 60, 185, 20);
        menuBar.setBounds (0, 0, 635, 25);
        textArea.setBounds (15, 90, 505, 350);

        createReservation.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                Reservation reservation = new Reservation();
                calculableList.add(reservation);
                Reservation.totalNumOfReservations++;
                reservation.setCustomerID(Reservation.GetCountReservations());

            }
        });

        reservationsButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                String reservations = "";
                for (Calculable serv : calculableList) {
                    if(serv instanceof Reservation) {
                        reservations += "Reservation ID " + ((Reservation)serv).CustomerID+ "#" + "\n" ;
                        reservations += ((Reservation)serv);
                        reservations += "\n";
                    }
                }
                textArea.setText(reservations);
                reservations = "";

            }
        });

        createService.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                int opt = Integer.parseInt(JOptionPane.showInputDialog("Please select one of the extra services from below:\n"
                        + "1. Laundry Service\n" + "2. Spa Service"));
                if (opt == 1) {
                    Laundry laundry = new Laundry();
                    calculableList.add(laundry);
                    int id = Integer.parseInt(JOptionPane.showInputDialog("Type the reservation ID to credit this service: "));
                    if (id <= Reservation.GetCountReservations())
                        laundry.setCustomerID(id);
                    else {
                        while (!(id <= Reservation.GetCountReservations())) {
                            JOptionPane.showMessageDialog(null,"İnvalid ID", "ERROR", JOptionPane.ERROR_MESSAGE);
                            id = Integer.parseInt(JOptionPane.showInputDialog("Type the reservation ID to credit this service: "));
                            laundry.setCustomerID(id);
                        }
                    }
                    try {
                        laundry.setClothingPieces(Integer.parseInt(JOptionPane.showInputDialog("How many pieces of clothing? ")));
                    } catch (Exception e1) {
                        JOptionPane.showMessageDialog(null,"Clothing count must be a numeric value!", "ERROR", JOptionPane.ERROR_MESSAGE);
                        laundry.setClothingPieces(Integer.parseInt(JOptionPane.showInputDialog("How many pieces of clothing? ")));
                    }
                } else if (opt == 2) {
                    Spa spa = new Spa();
                    calculableList.add(spa);
                    int id = Integer.parseInt(JOptionPane.showInputDialog("Type the reservation ID to credit this service:"));
                    if (id <= Reservation.GetCountReservations())
                        spa.setCustomerID(id);
                    else {
                        while (!(id <= Reservation.GetCountReservations())) {
                            JOptionPane.showMessageDialog(null,"İnvalid ID", "ERROR", JOptionPane.ERROR_MESSAGE);
                            id = Integer.parseInt(JOptionPane.showInputDialog("Type the reservation ID to credit this service:"));
                            spa.setCustomerID(id);
                        }
                    }
                    try {
                        spa.setDays(Integer.parseInt(JOptionPane.showInputDialog("How many days? ")));
                    } catch (Exception e1) {
                        JOptionPane.showMessageDialog(null,"Day count must be a numeric value!", "ERROR", JOptionPane.ERROR_MESSAGE);
                        spa.setDays(Integer.parseInt(JOptionPane.showInputDialog("How many days? ")));
                    }
                    System.out.println();

                }
            }
        });

        servicesButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                String services = "";

                for (Calculable serv : calculableList) {
                    if (serv instanceof Laundry) {
                        services += "Reservation ID " + ((Services) serv).getCustomerID() + " has " +
                                ((Laundry) serv).getClothingPieces()+ " pieces assigned for Laundry Service\n";
                    }
                    else if (serv instanceof Spa) {
                        services += "Reservation ID " + ((Services) serv).getCustomerID() + " has " +
                                ((Spa) serv).getDays() + " days of SPA services\n";
                    }
                }
                textArea.setText(services);
                services = "";
            }
        });

        cityButton.addActionListener(new ActionListener() {
            String city = "";
            public void actionPerformed(ActionEvent e) {
                String cityname = JOptionPane.showInputDialog("Type a city name: ");
                for (Calculable item : calculableList) {
                    if (item instanceof Reservation) {
                        String cityName = ((Reservation)item).getCityName();
                        if (cityName.equals(cityname)) {
                            city += "Reservation for " + cityname + ":\n" ;
                            city += "Reservation ID " + ((Reservation)item).getCustomerID() + "#\n";
                            city += ((Reservation)item).toString();
                        }
                    }
                }
                textArea.setText(city);
                city = "";
            }
        });

        exitItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {
                System.exit(0);
            }
        });


        contentsItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {

                JOptionPane.showMessageDialog(null, "You can add reservation or service by using the 'New' button \n "
                        + "if you want you can access the information by pressing the relevant buttons.", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        aboutItem.addActionListener(new java.awt.event.ActionListener() {

            public void actionPerformed(java.awt.event.ActionEvent evt) {

                JOptionPane.showMessageDialog(null, " Semih Can Karakaş\n 20200305040\n" + " semihcan.karakas@stu.pirireis.edu.tr  \n","About Developer" , JOptionPane.INFORMATION_MESSAGE);
            }
        });


    }

    public static void main(String[] args) {

        HotelReservation hotelReservation = new HotelReservation();
        hotelReservation.setTitle("Hotel Reservation System");
        hotelReservation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        hotelReservation.setSize(550,500);
        hotelReservation.isResizable();
        hotelReservation.setLocationRelativeTo(null);
        hotelReservation.setVisible(true);
    }
};
