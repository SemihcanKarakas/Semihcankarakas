import java.util.Scanner;
import javax.swing.JOptionPane;

public class Reservation extends Services{

    private String hotelName;
    private String cityName;
    private String reservationMonth;
    private int reservationStart;
    private int reservationEnd ;
    private int dailyCost;
    Scanner input = new Scanner(System.in);
    static int totalNumOfReservations = 0;

    public Reservation(){


        String cityName = JOptionPane.showInputDialog("Enter City: ");
        setCityName(cityName);


        String hotelName = JOptionPane.showInputDialog("Enter Hotel Name: ");
        setHotelName(hotelName);


        String ReservationMonth = JOptionPane.showInputDialog("Reservation Month: ");
        setReservationMonth(ReservationMonth);

        try {
            int ReservationStart = Integer.parseInt(JOptionPane.showInputDialog("Reservation Start: "));
            setReservationStart(ReservationStart);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Reservation Start must be a numeric value!", "ERROR", JOptionPane.ERROR_MESSAGE);
            int ReservationStart = Integer.parseInt(JOptionPane.showInputDialog("Reservation Start: "));
            setReservationStart(ReservationStart);
        }

        try {
            int ReservationEnd = Integer.parseInt(JOptionPane.showInputDialog("Reservation End: "));
            setReservationEnd(ReservationEnd);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Reservation End must be a numeric value!", "ERROR", JOptionPane.ERROR_MESSAGE);
            int ReservationEnd = Integer.parseInt(JOptionPane.showInputDialog("Reservation End: "));
            setReservationEnd(ReservationEnd);
        }

    }
    public void setCityName(String cityName) {
        this.cityName = cityName;

    }
    public String getCityName() {
        return cityName;

    }


    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    @Override
    public String toString() {
        return "Reservation at " + getHotelName() +
                " starts on " +  getReservationMonth() + " " + getReservationStart() + " and ends on " + getReservationMonth() + " " + getReservationEnd();
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setReservationMonth(String reservationMonth) {
        if(CheckMonth(reservationMonth)) {
            this.reservationMonth = reservationMonth;
        }
        else {

            String newReservationMonth = reservationMonth;
            while(!(CheckMonth(newReservationMonth))) {
                JOptionPane.showMessageDialog(null, "Wrong input try again(You must be begin with capital letter):", "ERROR", JOptionPane.ERROR_MESSAGE);
                newReservationMonth = JOptionPane.showInputDialog("Reservation Month: ");
                this.reservationMonth = newReservationMonth;
            }
        }
    }
    public String getReservationMonth() {
        return reservationMonth;
    }
    public void setReservationStart(int reservationStart) {
        if(reservationStart<31 && reservationStart>0) {
            this.reservationStart = reservationStart;
        }
        else {
            int newReservationStart = reservationStart;
            while(!(newReservationStart<31 && newReservationStart>0)) {
                JOptionPane.showMessageDialog(null, "Reservation Start must be smaller than '30'"
                        + " and grather than '0'!", "ERROR", JOptionPane.ERROR_MESSAGE);
                newReservationStart = Integer.parseInt(JOptionPane.showInputDialog("Reservation Start: "));
                this.reservationStart = newReservationStart;
            }
        }
    }
    public int getReservationStart() {
        return reservationStart;
    }
    public void setReservationEnd(int reservationEnd) {
        if(reservationEnd<31 && reservationEnd>reservationStart) {
            this.reservationEnd = reservationEnd;
        }
        else {
            int newReservationEnd = reservationEnd;
            while(!(newReservationEnd<31 && newReservationEnd>reservationStart)) {
                JOptionPane.showMessageDialog(null, "Reservation End must be smaller than Reservation Start"
                        + " and also it can not be grather than '30'!", "ERROR", JOptionPane.ERROR_MESSAGE);
                newReservationEnd = Integer.parseInt(JOptionPane.showInputDialog("Reservation End: "));
                this.reservationEnd = newReservationEnd;
            }
        }
    }
    public int getReservationEnd() {
        return reservationEnd;
    }
    public void setDailyCost(int dailyCost) {
        this.dailyCost = dailyCost;
    }
    public int getDailyCost() {
        return dailyCost;
    }
    public static int GetCountReservations() {
        return totalNumOfReservations;
    }
    public static boolean CheckMonth(String input) {
        String[] Month = {"January","February","March","April","May","June","July","August","September","November","December"};
        for (String month : Month) {
            if(input.equals(month))
                return true;
        }
        return false;
    }
}
