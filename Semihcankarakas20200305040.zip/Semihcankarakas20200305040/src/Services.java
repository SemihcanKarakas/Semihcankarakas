public abstract class Services implements Calculable{

    protected int CustomerID;


    public int getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(int customerID) {
        CustomerID = customerID;
    }


}
