public interface Calculable {

}
